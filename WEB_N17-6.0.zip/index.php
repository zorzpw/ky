<head>
<!-- 以下方式定时转到其他页面 -->
<meta http-equiv="refresh" content="0;url=/user"> 
</head>
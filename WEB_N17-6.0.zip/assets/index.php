<?php
header("HTTP/1.1 404 Not Found");
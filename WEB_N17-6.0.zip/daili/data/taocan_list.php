<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='../Kyun';</script>");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title> - 套餐列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;width: 100%">
<section class="panel panel-default">
  <div class="ibox-title">
                        <h5>平台套餐列表<small> 套餐管理</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
<div class="panel-body">
				
<div class="form-group">
<?php
$my=isset($_GET['my'])?$_GET['my']:null;
$user=$_GET['user'];
if($my=='del_user'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除无用套餐结果</h3></div>
<div class="panel-body box">';
if($DB->query("DELETE FROM `ky_tc` WHERE dlid='$dlid' && id='$user'")==true){
echo '<div class="box">恭喜亲成功清除该套餐</div>';
}else{
echo '<div class="box">奥，清除该记录失败,请稍后重新尝试.</div>';
}
echo '<hr/><a href="./taocan_list.php" class="btn btn-success">返回套餐列表</a></div></div>';
}
else{
$numrows=$DB->count("SELECT count(*) from `ky_tc` WHERE dlid='$dlid'");
$con='平台共有 <b>'.$numrows.'</b> 个商品';
echo '<form><a href="add_taocan.php" class="btn btn-primary">添加套餐</a>
    <a href="#" class="btn btn-info"><b>'.$con.'</b></a></form>';

?>
      <div class="table-responsive">
         <table class="table table-bordered table-hover">
          <thead><tr><th class="text-center">ID</th><th class="text-center">商品名称</th><th class="text-center">计费方式</th><th class="text-center">套餐流量</th><th class="text-center">天数</th><th class="text-center">金额</th><th class="text-center">操作</th></tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM `ky_tc` WHERE dlid='{$dlid}' order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
	
{ ?>
 

<tr>
<?php

if($res["i"] == "1" ){
	$i='<span class="label label-primary">按时间计费</span>';
	}elseif($res['i'] == "2"){
		$i='<span class="label label-success">按流量计费</span>';
	}		
?>
<tr>
<td class="text-center"><?=$res['id']?></td>
<td class="text-center"><?=$res['name']?><?=$p?></td>
<td class="text-center"><?=$i?></td>
<td class="text-center"><?=$res['G']?> GB</td>
<td class="text-center"><?=$res['tian']?></td>
<td class="text-center"><?=$res['money']?> 元</td>
<td class="text-center"><a class="btn btn-xs btn-success" href="./taocan_set.php?id=<?=$res['id']?>">编辑</a><a href="./taocan_list.php?my=del_user&user=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
</tr>

<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="taocan_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="taocan_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="taocan_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="taocan_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="taocan_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="taocan_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>

 
                  
              </div>
            </section>
			  </div>
                        </div>
                    </div>
                </div>
    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    </body>
</html>

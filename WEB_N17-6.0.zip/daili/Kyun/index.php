<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
header('Content-Type: text/html; charset=UTF-8');
if(isset($_POST['user']) && isset($_POST['pass'])){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$_SESSION['dlid']=$row['id'];
	if($user==$row['user'] && $pass==$row['pass']) {
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		if($row['active']=='0'){
	     exit("<script language='javascript'>alert('账号未激活，请联系管理员激活！');history.go(-1);</script>");}
		exit("<script language='javascript'>alert('登陆管理中心成功！');window.location.href='../data';</script>");
	}elseif ($pass != $row['pass']) {
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("ol_token", "", time() - 604800);
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='../data';</script>");
}
exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<?php
$u = $_GET['username'];
if($_GET['dlapp']){
$dlid =  $_GET['dlapp'];
}else{
$dlid = '0';
}
$tcA = db('ky_tc')->where(array('i'=>'2','dlid'=>$dlid))->order('id DESC')->select();
$tcB = db('ky_tc')->where(array('i'=>'1','dlid'=>$dlid))->order('id DESC')->select();	
echo '<div style="margin:10px 10px;">';
			echo '<div class="alert alert-info"><h4>购买前请认真看介绍哦<br>
			    <h5>1.购买按流量计费的有效期为套餐的天数,请您在有效期内使用完哦！
			<br>2.购买按时间计费的套餐不会限制你的使用流量哦！所以尽情的浪吧 ~.~</h5></div>';
			echo '</div>';
			echo '<ul class="list-group">';
echo '<div class="main"><li class="list-group-item"><h4>按流量计费套餐</h4>';
echo'<form action="mode/pay/payapi.php?u='.$u.'&dlid='.$dlid.'" method="post">';
foreach($tcA as $v){
echo '<input type="radio" name="shop_name" value="'.$v['name'].'"> '.$v['name'].'-----'.$v['money'].'元<br>';	
}
echo'<br><button type="submit" class="btn btn-default" name="shop_pay" value="alipay"><img src="mode/pay/alipay.ico""/> 支付宝</button>&nbsp;
	   <button type="submit" class="btn btn-default" name="shop_pay" value="qqpay"><img src="mode/pay/qqpay.ico""/> QQ钱包</button>&nbsp;
	   <button type="submit" class="btn btn-default" name="shop_pay" value="wxpay"><img src="mode/pay/wxpay.ico""/>微信支付</button><hr>    
       </form>'; 
echo '<h4>按时间计费套餐</h4>';
echo'<form action="mode/pay/payapi.php?u='.$u.'&dlid='.$dlid.'" method="post">';
foreach($tcB as $vo){
echo '<input type="radio" name="shop_name" value="'.$vo['name'].'" > '.$vo['name'].'-----'.$vo['money'].'元<br>';	
}
echo'<br><button type="submit" class="btn btn-default" name="shop_pay" value="alipay"><img src="mode/pay/alipay.ico""/> 支付宝</button>&nbsp;
	   <button type="submit" class="btn btn-default" name="shop_pay" value="qqpay"><img src="mode/pay/qqpay.ico""/> QQ钱包</button>&nbsp;
	   <button type="submit" class="btn btn-default" name="shop_pay" value="wxpay"><img src="mode/pay/wxpay.ico""/>微信支付</button>  
       </form>'; 
		echo '</li></ul></div>';
  ?><center>
		<div style="color:#ccc;font-size:12px;">我们一直在努力创新 只为给你带来更完美</div>
	</center>
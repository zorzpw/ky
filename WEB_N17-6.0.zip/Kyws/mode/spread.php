<?php
$u = $_GET['username'];
$h=date('G');
if ($h<11){
$s = '早上好哦';	
}elseif ($h<13){
$s = '中午好哦';
}elseif ($h<17){
$s = '下午好哦';
}else{
$s = '晚上好哦';	
} 
$value = 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/Kyws/spread/index.php?user='.$u.'';   
		echo '<div style="margin:10px 10px;">';
			echo '<div class="alert alert-info"><h5>尊敬的'.$u.','.$s.'!</h5>每推广成功一人系统就会赠送 '.$reg[user_reg_cash].'M流量到你的账户哦，宝宝们加油为自己挣点流量哦！~.~</div>';
			echo '</div>';
			echo '<div class="main"><ul class="list-group">';
				echo '<li class="list-group-item"><h5>我的推广链接</h5>
				<input type="text" class="form-control" value="'.$value.'" name="diqu" required="required"/>';
				echo'<div style="width:160px;margin:20px auto;"><h4>或扫描下方二维码</h4>';
				echo '<img src="http://api.qrserver.com/v1/create-qr-code/?size=150x150&data='.$value.'"></div>'; 
		echo '</li></ul></div>';
  ?><center>
		<div style="color:#ccc;font-size:12px;">我们一直在努力创新 只为给你带来更完美</div>
	</center>
<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$row = $DB->get_row("SELECT * FROM kyun"); 	
if(isset($_GET['logout'])){
unset($_SESSION['user']);      //注销在该会话中的该会话变量  
unset($_SESSION['pass']);      //注销在该会话中的该会话变量  
session_destroy();      //销毁该会话  
@header('Content-Type: text/html; charset=UTF-8');
exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./index.php';</script>");}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no"/>

    <link rel="shortcut icon" href="../img/favicon_1.ico">

    <title>用户登录 - <?php echo $row['logo'];?></title>
    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">
	<link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/core.css" rel="stylesheet" type="text/css">
    <link href="css/components.css" rel="stylesheet" type="text/css">
    <link href="css/pages.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">


</head>
<body>


<div class="wrapper-page">
    <div class="panel panel-color panel-primary panel-pages">
        <div class="panel-heading bg-img">
            <div class="bg-overlay"></div>
            <h3 class="text-center m-t-10 text-white"><strong><?php echo $row['logo'];?>用户前台 - 登录</strong> </h3>
        </div>

        <div class="panel-body">
            <form class="form-horizontal m-t-20" action="../data/index.php?user=<?php echo $_GET[user];?>&pass=<?php echo $_GET[pass];?>" method="get">

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="text" required="" name="user" placeholder="请输入账号">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="password" required="" name="pass" placeholder="请输入密码">
                    </div>
                </div>

                 <div class="form-group text-center m-t-40">
                    <div class="col-xs-12">
                        <button class="btn btn-primary form-control" type="submit">立 即 登 录</button>
                    </div>
                </div>

                <div class="form-group m-t-30">
                    <div class="col-sm-7">
                        <a onclick="alert('请联系你的上级找回密码哦！')"><i class="fa fa-lock m-r-5"></i> 忘记密码?</a>
                    </div>
                    <div class="col-sm-5 text-right">
                        <a href="reg_user.php">免费注册</a>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
</body>
</html>
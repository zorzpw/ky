<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$a_time = time();
$u = $_GET['user'];
$p = $_GET['pass'];
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){ header('location: ../Kyun/index.php');exit;}
if($_GET['my'] == 'add'){	
$km = daddslashes($_GET['km']);
$myrow=$DB->get_row("select * from auth_kms where kind=1 and km='$km' limit 1"); 
if(!$myrow){ exit("<script language='javascript'>alert('此激活码不存在');window.location.href='index.php?user=".$u."&pass=".$p."';</script>");
}elseif($myrow['isuse']==1){
exit("<script language='javascript'>alert('此激活码已被使用');window.location.href='index.php?user=".$u."&pass=".$p."';</script>");
}else{
$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
$addll = $myrow['values']*1024*1024*1024; 
if($res['endtime'] < time()){ 
$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
if($DB->query($sql)){ 
$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
wlog('账号激活','用户'.$u.'使用激活码'.$km.'开通账号['.$date.']');
exit("<script language='javascript'>alert('开通成功！');window.location.href='index.php?user=".$u."&pass=".$p."';</script>"); 
}else{ 
exit("<script language='javascript'>alert('开通失败！');window.location.href='index.php?user=".$u."&pass=".$p."';</script>"); 
} 
}else{
$duetime =  time() + $myrow['value']*24*60*60;
$sql="update `openvpn` set `maxll`='{$addll}',`isent`='0',`irecv`='0',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
if($DB->query($sql)){ $DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
exit("<script language='javascript'>alert('续费成功！');window.location.href='index.php?user=".$u."&pass=".$p."';</script>"); 
}else{ 
exit("<script language='javascript'>alert('续费失败！');window.location.href='index.php?user=".$u."&pass=".$p."';</script>"); } } } } 
$config = $DB->get_row("SELECT * FROM auth_config"); 
$gonggao=$config['ggs'];
if($res["i"] == "1" ){
$zht= '<a class="btn btn-xs btn-info">状态: 已开通</a>';
}elseif($res['i'] == "2"){
$zht= '<a class="btn btn-xs btn-warning">状态: 未激活</a>';
}else{
$zht= '<a class="btn btn-xs btn-danger">状态: 已禁用</a>';}
$img = rand(1,9);
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">

    <title>管理员平台 - N17-3.0</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>	
<body class="gray-bg">
    <div class="wrapper wrapper-content">
        <div class="row">
			    <div class="col-sm-4">
					<div>
                       <div class="ibox-content text-center">
                               <div class="m-b-sm">
                                    <img alt="image" class="img-circle" src="../../assets/img/a<?php echo $img;?>.jpg">
                                </div>
                                <p class="font-bold">用户名：<?php echo $res['iuser'];?></p>

                                <div class="text-center">
                                    <a class="btn btn-xs btn-primary">ID：<?php echo $res['id'];?></a>
									<?=$zht;?>
                                </div>
                            </div>
							 </div>
							<br>
						</div>
                  <div class="col-sm-2"> 
                        <div class="row row-sm text-center">
                            <div class="col-xs-12">
                                <div class="panel padder-v item bg-info">
                                    <div class="h1 text-fff font-thin h1"><?php echo round(($res['endtime']-$res['starttime'])/86400);?></div>
                                    <span class="text-muted text-xs">总天数</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
                            </div>
							<br>
                            <div class="col-xs-12">
                                <div class="panel padder-v item bg-primary">
                                    <div class="h1 text-fff font-thin h1"><?php echo round(($res['endtime']-$a_time)/86400);?></div>
                                    <span class="text-muted text-xs">剩余天数</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
						      </div>
						</div>
                     </div>
                 <div class="col-sm-6">
                <div class="ibox float-e-margins">
					   <div class="ibox-content" style="border-top:none;background-color:#e4eaec;">
					     <h4>用户流量使用信息</h4>
						    <br>
                                 <h5>发送的数据流量</h5>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar progress-bar-warning"><h5><?php echo round($res['isent']/1024/1024);?> MB</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
								<h5>接收的数据流量</h5>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar progress-bar-danger"><h5><?php echo round($res['irecv']/1024/1024);?> MB</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
								 <h5>剩余的数据流量</h5>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar"><h5><?php echo round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024);?> MB</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
				 </div>
             <div class="row">
			  <div class="col-sm-6">
                 <div class="panel panel-default">
                    <div class="ibox-title">
                        <h5>用户流量充值<small> 余额充值</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="panel-body">
				  <div class="form-group">  
			  <div class="panel-heading w h">
			  <h3 class="panel-title">请在下方输入激活码</h3></div>
               <div class="panel-body box">
               <form action="./N17_user.php?my=add&user=<?php echo $u;?>&pass=<?php echo $p;?>" method="get" class="form-inline" role="form">
             <div class="form-group">
              <input type="text" name="km" value="" class="form-control" required/>
            </div>
            <input type="submit" value="充值" class="btn btn-primary"/>
          </form>
			    </div>
				   </div>
                    </div>
                </div>
            </div>
				 <div class="col-sm-6">
				    <div class="ibox float-e-margins">

                            <div id="vertical-timeline" class="vertical-container light-timeline">
                                    <div class="vertical-timeline-icon navy-bg">
                                        <i class="fa fa-volume-up"></i>
                                    </div>

                                    <div class="vertical-timeline-content">
                                        <h2>最新公告信息</h2>
                                        <p><?php echo $gonggao;?></p>
                                        <small class="btn btn-sm">来自超级管理员</small>
                                        <span class="vertical-date">
                                     <small><?php echo date( "Y年m月d日") ?></small>
                                </span>
                            </div>
                         </div>
                    </div>
                </div>
            </div>
    </div>
    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="../../assets/js/plugins/layer/layer.min.js"></script>
    <!-- Flot -->
    <script src="../../assets/js/plugins/flot/jquery.flot.js"></script>
	<script src="../../assets/js/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.pie.js"></script>
    <!-- 自定义js -->
    <script src="../../assets/js/content.js"></script>


<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>	
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>代理管理 - 添加代理</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> <link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="../../assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>代理管理 >><small>添加代理</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">				
<?php
if($_POST['user']){
echo '
<div class="panel-heading w h"><h3 class="panel-title">添加代理账号结果</h3></div>
<div class="panel-body box">';	
$user = daddslashes($_POST['user']);
$pass = daddslashes($_POST['pass']);
$qq = daddslashes($_POST['qq']);
$vip = daddslashes($_POST['vip']);
$zt = daddslashes($_POST['zt']);
$rmb = daddslashes($_POST['rmb']);
if(!$DB->get_row("select * from `auth_daili` where `iuser`='$user' limit 1")){
$sql="insert into `auth_daili` (`PayUser`,`PayKey`,`qq`,`user`,`pass`,`rmb`,`vip`,`active`,`regdate`) values ('请到http://kypay.top申请','请到http://kypay.top申请','{$qq}','{$user}','{$pass}','{$rmb}',{$vip},'{$zt}','{$data}')";	
if($DB->query($sql))					 
echo '<div class="box">恭喜亲，成功添加代理账号</div>';
else
echo '<div class="box">奥，添加代理失败,请稍后重新尝试.</div>';
}else{
echo '<div class="box">亲，该代理已经存在,请不要重复添加.</div>';
}
echo '<hr/><a href="./daili_list.php" class="btn btn-success">返回代理列表</a></div></div>';}
else{
echo'					
                        <form action="./add_daili.php" method="post" class="form-horizontal">
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">账号</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="user">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                           
                            <div class="form-group has-error">
                                <label class="col-sm-2 control-label">密码</label>

                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="pass">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">VIP等级</label>

                                <div class="col-sm-3">
                                    <select class="form-control m-b" name="vip">
									    <option value="0">青铜代理</option>
                                        <option value="1">白银代理</option>
                                        <option value="2">黄金代理</option>
										<option value="3">铂金代理</option>
										<option value="4">钻石代理</option>
										<option value="5">王者代理</option>
                                    </select>
                                </div>
                                <label class="col-sm-2 control-label">联系QQ</label>

                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="qq">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">账号状态</label>

                                <div class="col-sm-3">
                                    <select class="form-control m-b" name="zt">
									    <option value="1">开通账号</option>
                                        <option value="0">禁用账号</option>
                                    </select>
                                </div>
                                <label class="col-sm-2 control-label">总余额(单位/元)</label>

                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="rmb">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-6 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>';
}?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>

    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    <!-- iCheck -->
    <script src="../../assets/js/plugins/iCheck/icheck.min.js"></script>

</body>

</html>

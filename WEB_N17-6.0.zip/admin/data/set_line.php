<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
$id = daddslashes($_GET['id']);
if(!$id || !$res = $DB->get_row("select * from `line` where id='$id' limit 1")){
exit("<script language='javascript'>alert('亲，平台找不到此线路！');window.location.href='./index.php';</script>");
}
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>线路管理 - 编辑线路</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> <link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="../../assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>线路管理 >><small>编辑线路</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="form_basic.html#">
                              </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
<?php
if ($_POST['content']) {
echo '
<div class="panel-heading w h"><h3 class="panel-title">批量添加账号结果</h3></div>
<div class="panel-body box">';	
$name = daddslashes($_POST['name']);
$label = daddslashes($_POST['sm']);
$group = daddslashes($_POST['group']);
$content = daddslashes($_POST['content']);
$sql = "update `line` set `name`='$name',`label`='$label',`group`='$group',`content`='$content',`type`='".date("Y-m-d")."' where id='$id'";
if ($DB->query($sql)){ 
echo '<div class="box">恭喜亲，成功修改该线路</div>';
}else{
echo '<div class="box">奥，修改该线路失败</div>';
}
echo '<hr/><a href="./line_list.php" class="btn btn-success">返回线路列表</a></div></div>';
exit;}?>    
                  <form action="./set_line.php?id=<?php echo $res['id'];?>" method="post" class="form-horizontal">
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">线路名称</label>

                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?php echo $res['name'];?>" name="name">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-error">
                                <label class="col-sm-2 control-label">线路说明</label>

                                <div class="col-sm-10">
                                   <input type="text" class="form-control" value="<?php echo $res['label'];?>" name="sm">
                                </div>
                            </div>
							
							 <div class="hr-line-dashed"></div>
                            <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">运营商选择：</label>
                                <div class="col-sm-10">
                                    <select class="form-control m-b" name="group">
									 <?php
                                   $rs=$DB->query("SELECT * FROM line_grop");
                                  while($ros = $DB->fetch($rs))							
                                  echo '<option value="'.$ros['id'].'">'.$ros['name'].'</option>';
                                            ?>
                                    </select>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
							<div class="form-group has-success">
                                 <label class="col-sm-2 control-label">免流代码：</label>
                                 <div class="col-sm-10">
                                   <textarea class="form-control" rows="10" name="content"><?php echo $res['content'];?></textarea>
                                 </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>	
    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>

    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    <!-- iCheck -->
    <script src="../../assets/js/plugins/iCheck/icheck.min.js"></script>

</body>

</html>
